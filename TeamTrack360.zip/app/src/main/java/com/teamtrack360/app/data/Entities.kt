package com.teamtrack360.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "circles")
data class CircleEntity(
    @PrimaryKey val code: String,
    val name: String,
    val adminId: String,
    val createdAt: Long
)

@Entity(tableName = "members", primaryKeys = ["circleCode", "userId"])
data class MemberEntity(
    val circleCode: String,
    val userId: String,
    val name: String,
    val isAdmin: Boolean,
    val canViewLive: Boolean = true,
    val canViewTrails: Boolean = true,
    val canReviewOwn: Boolean = true,
    val lat: Double? = null,
    val lon: Double? = null,
    val battery: Int = -1,
    val charging: Boolean = false,
    val gpsOn: Boolean = true,
    val gpsOffSince: Long? = null,
    val lastSeen: Long = 0L
)

@Entity(
    tableName = "trail_points",
    indices = [Index(value = ["circleCode", "userId", "time"])]
)
data class TrailPoint(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val circleCode: String,
    val userId: String,
    val lat: Double,
    val lon: Double,
    val time: Long
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val circleCode: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val time: Long,
    val synced: Boolean
)
