package com.teamtrack360.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.teamtrack360.app.data.MemberEntity
import com.teamtrack360.app.data.SessionState
import com.teamtrack360.app.data.TrailPoint
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

data class MapMarker(val id: String, val title: String, val pos: GeoPoint)

private fun colorFor(uid: String): Int =
    android.graphics.Color.HSVToColor(floatArrayOf(uid.hashCode().mod(360).toFloat(), 0.85f, 0.75f))

@Composable
fun MapTab(s: SessionState, members: List<MemberEntity>, points: List<TrailPoint>) {
    val ctx = LocalContext.current

    val me = members.find { it.userId == s.userId }
    val admin = me?.isAdmin == true
    val seeLive = admin || me?.canViewLive == true
    val seeTrails = admin || me?.canViewTrails == true
    val seeOwn = admin || me?.canReviewOwn == true

    val markers = members
        .filter { it.lat != null && it.lon != null && (it.userId == s.userId || seeLive) }
        .map {
            val batt = if (it.battery >= 0) " · ${it.battery}%" else ""
            MapMarker(it.userId, it.name + batt, GeoPoint(it.lat!!, it.lon!!))
        }
    val trails = points.groupBy { it.userId }
        .filter { (uid, _) -> if (uid == s.userId) seeOwn else seeTrails }
        .mapValues { e -> e.value.sortedBy { it.time }.map { GeoPoint(it.lat, it.lon) } }
    val myPos = markers.find { it.id == s.userId }?.pos

    val mapView = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(15.0)
            controller.setCenter(GeoPoint(14.5995, 120.9842))
        }
    }
    var centered by remember { mutableStateOf(false) }
    LaunchedEffect(myPos) {
        if (myPos != null && !centered) {
            mapView.controller.setCenter(myPos)
            centered = true
        }
    }
    DisposableEffect(mapView) {
        mapView.onResume()
        onDispose {
            mapView.onPause()
            mapView.onDetach()
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { mapView },
            modifier = Modifier.fillMaxSize(),
            update = { mv ->
                mv.overlays.clear()
                trails.forEach { (uid, pts) ->
                    if (pts.size > 1) {
                        val line = Polyline()
                        line.setPoints(pts)
                        line.outlinePaint.color = colorFor(uid)
                        line.outlinePaint.strokeWidth = 7f
                        mv.overlays.add(line)
                    }
                }
                markers.forEach { m ->
                    val mk = Marker(mv)
                    mk.position = m.pos
                    mk.title = m.title
                    mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    mv.overlays.add(mk)
                }
                mv.invalidate()
            }
        )
        Button(
            onClick = { myPos?.let { mapView.controller.animateTo(it) } },
            modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp)
        ) { Text("📍 Me") }
        if (!seeLive) {
            Surface(
                modifier = Modifier.align(Alignment.TopCenter).padding(8.dp),
                color = MaterialTheme.colorScheme.errorContainer,
                shape = MaterialTheme.shapes.small
            ) { Text("Admin has hidden others' live locations", Modifier.padding(8.dp)) }
        }
    }
}
