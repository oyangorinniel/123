package com.teamtrack360.app.sync

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.teamtrack360.app.data.AppDb
import com.teamtrack360.app.data.MessageEntity
import java.util.concurrent.TimeUnit

/** Plug a cloud backend (e.g. Firebase Firestore) in here later. */
interface SyncBackend {
    suspend fun pushMessage(m: MessageEntity): Boolean
}

/** Local / Offline mode: nothing leaves the device, so pushing always succeeds. */
object LocalBackend : SyncBackend {
    override suspend fun pushMessage(m: MessageEntity): Boolean = true
}

object Backends {
    @Volatile var current: SyncBackend = LocalBackend
}

class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val dao = AppDb.get(applicationContext).dao()
        for (m in dao.unsynced()) {
            if (Backends.current.pushMessage(m)) dao.markSynced(m.id) else return Result.retry()
        }
        dao.pruneTrails(System.currentTimeMillis() - 30L * 24 * 3600 * 1000)
        return Result.success()
    }
}

object SyncScheduler {
    private fun online() = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun kick(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(online())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("sync-now", ExistingWorkPolicy.APPEND_OR_REPLACE, req)
    }

    fun periodic(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(online())
            .build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork("sync-periodic", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}
