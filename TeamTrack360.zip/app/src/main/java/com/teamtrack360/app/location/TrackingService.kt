package com.teamtrack360.app.location

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.teamtrack360.app.data.AppDb
import com.teamtrack360.app.data.SessionStore
import com.teamtrack360.app.data.TrailPoint
import com.teamtrack360.app.data.hasLocationPermission
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Battery/data friendly: GPS every ~15 s / 10 m, network fallback, status heartbeat every 60 s. */
class TrackingService : Service(), LocationListener {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var lm: LocationManager
    private var last: Location? = null
    private var heartbeat: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!hasLocationPermission(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        startUpdates()
        if (heartbeat == null) {
            heartbeat = scope.launch {
                while (isActive) {
                    pushStatus()
                    delay(60_000)
                }
            }
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "tracking"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Location sharing", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("TeamTrack 360")
            .setContentText("Sharing your location with your circle")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    @SuppressLint("MissingPermission")
    private fun startUpdates() {
        try { lm.removeUpdates(this) } catch (_: Exception) {}
        try {
            if (lm.allProviders.contains(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 60_000L, 50f, this)
        } catch (_: SecurityException) {}
        try {
            if (lm.allProviders.contains(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 15_000L, 10f, this)
        } catch (_: SecurityException) {}
    }

    override fun onLocationChanged(location: Location) {
        if (location.accuracy > 100f) return
        last = location
        scope.launch {
            val s = SessionStore(this@TrackingService).load()
            val code = s.circleCode
            val uid = s.userId
            if (code != null && uid != null) {
                AppDb.get(this@TrackingService).dao().addPoint(
                    TrailPoint(
                        circleCode = code, userId = uid,
                        lat = location.latitude, lon = location.longitude,
                        time = System.currentTimeMillis()
                    )
                )
            }
            pushStatus()
        }
    }

    override fun onProviderEnabled(provider: String) {
        scope.launch { pushStatus() }
    }

    override fun onProviderDisabled(provider: String) {
        scope.launch { pushStatus() }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
    }

    private suspend fun pushStatus() {
        val s = SessionStore(this).load()
        val code = s.circleCode ?: return
        val uid = s.userId ?: return
        val dao = AppDb.get(this).dao()
        val old = dao.member(code, uid) ?: return

        val gpsOn = try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (_: Exception) { false }
        val now = System.currentTimeMillis()
        val offSince: Long? = if (gpsOn) null else (old.gpsOffSince ?: now)

        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL

        val loc = last
        dao.updateStatus(
            code, uid, loc?.latitude ?: old.lat, loc?.longitude ?: old.lon,
            pct, charging, gpsOn, offSince, now
        )
    }

    override fun onDestroy() {
        try { lm.removeUpdates(this) } catch (_: Exception) {}
        scope.cancel()
        super.onDestroy()
    }
}
