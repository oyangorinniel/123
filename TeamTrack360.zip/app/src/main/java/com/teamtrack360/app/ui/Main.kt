package com.teamtrack360.app.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.teamtrack360.app.data.MemberEntity
import com.teamtrack360.app.data.MessageEntity
import com.teamtrack360.app.data.SessionState
import com.teamtrack360.app.data.hasLocationPermission
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmt(t: Long): String = SimpleDateFormat("HH:mm, d MMM", Locale.getDefault()).format(Date(t))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val s by vm.session.collectAsState()
    val members by vm.members.collectAsState()
    val points by vm.points.collectAsState()
    val messages by vm.messages.collectAsState()
    val circle by vm.circle.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    val perms = remember {
        buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.ensureService()
    }
    LaunchedEffect(Unit) {
        if (!hasLocationPermission(ctx)) launcher.launch(perms) else vm.ensureService()
    }

    val tabs = listOf("🗺️" to "Map", "👥" to "Team", "💬" to "Chat", "⚙️" to "Me")

    Scaffold(
        topBar = { TopAppBar(title = { Text(circle?.name ?: "TeamTrack 360") }) },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icon) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> MapTab(s, members, points)
                1 -> TeamTab(vm, s, members)
                2 -> ChatTab(vm, s, messages)
                else -> MeTab(vm, s)
            }
        }
    }
}

@Composable
fun TeamTab(vm: MainViewModel, s: SessionState, members: List<MemberEntity>) {
    val ctx = LocalContext.current
    val iAmAdmin = members.find { it.userId == s.userId }?.isAdmin == true

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Circle code", style = MaterialTheme.typography.labelMedium)
                    Text(
                        s.circleCode ?: "",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 4.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "Join my TeamTrack 360 circle with code ${s.circleCode}")
                            }
                            ctx.startActivity(Intent.createChooser(send, "Share code"))
                        }) { Text("Share code") }
                        OutlinedButton(onClick = { vm.addDemoMember() }) { Text("+ Demo member") }
                    }
                }
            }
        }
        items(members, key = { it.userId }) { m ->
            MemberCard(vm, m, iAmAdmin, m.userId == s.userId)
        }
    }
}

@Composable
fun MemberCard(vm: MainViewModel, m: MemberEntity, iAmAdmin: Boolean, isMe: Boolean) {
    val now = System.currentTimeMillis()
    val (status, color) = when {
        !m.gpsOn -> "GPS OFF since ${fmt(m.gpsOffSince ?: m.lastSeen)}" to Color(0xFFD32F2F)
        m.lastSeen == 0L -> "No data yet" to Color.Gray
        now - m.lastSeen < 3 * 60_000L -> "Live · ${fmt(m.lastSeen)}" to Color(0xFF2E7D32)
        else -> "Offline · last seen ${fmt(m.lastSeen)}" to Color(0xFFF9A825)
    }
    val battery = (if (m.battery < 0) "🔋 --" else "🔋 ${m.battery}%") + (if (m.charging) "  ⚡ charging" else "")

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    m.name + if (isMe) " (you)" else "",
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.titleMedium
                )
                if (m.isAdmin) {
                    Spacer(Modifier.width(8.dp))
                    Text("ADMIN", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                }
            }
            Text("● $status", color = color)
            Text(battery)
            if (iAmAdmin && !m.isAdmin) {
                Spacer(Modifier.width(4.dp))
                PermRow("View others' live locations", m.canViewLive) { vm.setPerms(m, it, m.canViewTrails, m.canReviewOwn) }
                PermRow("View others' GPS trails", m.canViewTrails) { vm.setPerms(m, m.canViewLive, it, m.canReviewOwn) }
                PermRow("Review own previous trails", m.canReviewOwn) { vm.setPerms(m, m.canViewLive, m.canViewTrails, it) }
            }
        }
    }
}

@Composable
fun PermRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ChatTab(vm: MainViewModel, s: SessionState, messages: List<MessageEntity>) {
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(messages, key = { it.id }) { m ->
                val mine = m.senderId == s.userId
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (mine) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            if (!mine) Text(m.senderName, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Text(m.text)
                            Text(
                                fmt(m.time) + if (m.synced) "  ✓ synced" else "  ⏳ queued",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message…") }, maxLines = 3
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.sendMessage(text); text = "" }, enabled = text.isNotBlank()) { Text("Send") }
        }
    }
}

@Composable
fun MeTab(vm: MainViewModel, s: SessionState) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(s.name ?: "Me", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        s.email?.let { Text(it) }
        Text(
            if (s.google) "Signed in with Google · data stored on this device"
            else "Local / Offline mode · data stored on this device",
            style = MaterialTheme.typography.bodySmall
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Share my location with the circle", Modifier.weight(1f))
            Switch(checked = s.sharing, onCheckedChange = { vm.setSharing(it) })
        }
        OutlinedButton(onClick = { vm.leaveCircle() }, modifier = Modifier.fillMaxWidth()) { Text("Leave circle") }
        TextButton(onClick = { vm.logout() }) { Text("Sign out") }
    }
}
