package com.teamtrack360.app

import android.app.Application
import com.teamtrack360.app.sync.SyncScheduler
import org.osmdroid.config.Configuration
import java.io.File

class TeamTrackApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val c = Configuration.getInstance()
        c.load(this, getSharedPreferences("osm", MODE_PRIVATE))
        c.userAgentValue = packageName
        c.osmdroidBasePath = File(cacheDir, "osmdroid")
        c.osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        SyncScheduler.periodic(this)
    }
}
