package com.teamtrack360.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

data class SessionState(
    val userId: String? = null,
    val name: String? = null,
    val email: String? = null,
    val circleCode: String? = null,
    val sharing: Boolean = false,
    val google: Boolean = false
)

class SessionStore(context: Context) {
    private val sp = context.getSharedPreferences("session", Context.MODE_PRIVATE)

    fun load() = SessionState(
        userId = sp.getString("uid", null),
        name = sp.getString("name", null),
        email = sp.getString("email", null),
        circleCode = sp.getString("circle", null),
        sharing = sp.getBoolean("sharing", false),
        google = sp.getBoolean("google", false)
    )

    fun save(s: SessionState) {
        sp.edit()
            .putString("uid", s.userId)
            .putString("name", s.name)
            .putString("email", s.email)
            .putString("circle", s.circleCode)
            .putBoolean("sharing", s.sharing)
            .putBoolean("google", s.google)
            .apply()
    }
}

fun hasLocationPermission(c: Context): Boolean =
    ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
