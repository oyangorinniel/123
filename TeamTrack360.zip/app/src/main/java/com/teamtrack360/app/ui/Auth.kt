package com.teamtrack360.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException

@Composable
fun Root(vm: MainViewModel = viewModel()) {
    val s by vm.session.collectAsState()
    when {
        s.userId == null -> LoginScreen(vm)
        s.circleCode == null -> CircleScreen(vm)
        else -> MainScreen(vm)
    }
}

@Composable
fun LoginScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        try {
            val acc = GoogleSignIn.getSignedInAccountFromIntent(res.data).getResult(ApiException::class.java)
            vm.loginGoogle(acc.id ?: acc.email ?: "user", acc.displayName ?: acc.email ?: "Me", acc.email)
        } catch (e: ApiException) {
            msg = "Google sign-in isn't available yet (code ${e.statusCode}). " +
                "Register this app's SHA-1 in Google Cloud / Firebase, or use Local mode below."
        }
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("TeamTrack 360", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Free family & team GPS circle")
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = {
                try {
                    val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build()
                    launcher.launch(GoogleSignIn.getClient(ctx, gso).signInIntent)
                } catch (e: Exception) {
                    msg = "Google Play services unavailable. Use Local mode."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Sign in with Google") }
        msg?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(28.dp))
        Text("Local / Offline mode", fontWeight = FontWeight.SemiBold)
        Text("No account needed. Data stays on this device.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { vm.loginLocal(name) }, modifier = Modifier.fillMaxWidth()) {
            Text("Continue offline")
        }
    }
}

@Composable
fun CircleScreen(vm: MainViewModel) {
    val err by vm.error.collectAsState()
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Your circle", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))

        Text("Create a circle (you become Admin)", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Circle name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = { vm.createCircle(name) }, modifier = Modifier.fillMaxWidth()) {
            Text("Create circle")
        }

        Spacer(Modifier.height(28.dp))
        Text("Join with a 6-character code", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = code,
            onValueChange = { code = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) },
            label = { Text("Code") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { vm.joinCircle(code) },
            enabled = code.length == 6,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Join circle") }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        Spacer(Modifier.height(24.dp))
        TextButton(onClick = { vm.logout() }) { Text("Sign out") }
    }
}
