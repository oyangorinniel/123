package com.teamtrack360.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface TeamDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCircle(c: CircleEntity)

    @Query("SELECT * FROM circles WHERE code = :code")
    suspend fun circle(code: String): CircleEntity?

    @Query("SELECT * FROM circles WHERE code = :code")
    fun circleFlow(code: String): Flow<CircleEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMember(m: MemberEntity)

    @Query("SELECT * FROM members WHERE circleCode = :code ORDER BY isAdmin DESC, name")
    fun members(code: String): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members WHERE circleCode = :code AND userId = :uid")
    suspend fun member(code: String, uid: String): MemberEntity?

    @Query(
        "UPDATE members SET lat = :lat, lon = :lon, battery = :battery, charging = :charging, " +
            "gpsOn = :gpsOn, gpsOffSince = :gpsOffSince, lastSeen = :lastSeen " +
            "WHERE circleCode = :code AND userId = :uid"
    )
    suspend fun updateStatus(
        code: String, uid: String, lat: Double?, lon: Double?, battery: Int,
        charging: Boolean, gpsOn: Boolean, gpsOffSince: Long?, lastSeen: Long
    )

    @Query(
        "UPDATE members SET canViewLive = :live, canViewTrails = :trails, canReviewOwn = :own " +
            "WHERE circleCode = :code AND userId = :uid"
    )
    suspend fun setPerms(code: String, uid: String, live: Boolean, trails: Boolean, own: Boolean)

    @Insert
    suspend fun addPoint(p: TrailPoint)

    @Query("SELECT * FROM trail_points WHERE circleCode = :code ORDER BY time DESC LIMIT 3000")
    fun allTrails(code: String): Flow<List<TrailPoint>>

    @Query("DELETE FROM trail_points WHERE time < :before")
    suspend fun pruneTrails(before: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addMessage(m: MessageEntity)

    @Query("SELECT * FROM messages WHERE circleCode = :code ORDER BY time")
    fun messages(code: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE synced = 0 ORDER BY time")
    suspend fun unsynced(): List<MessageEntity>

    @Query("UPDATE messages SET synced = 1 WHERE id = :id")
    suspend fun markSynced(id: String)
}

@Database(
    entities = [CircleEntity::class, MemberEntity::class, TrailPoint::class, MessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TeamDao

    companion object {
        @Volatile private var instance: AppDb? = null

        fun get(context: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AppDb::class.java, "teamtrack.db"
            ).build().also { instance = it }
        }
    }
}
