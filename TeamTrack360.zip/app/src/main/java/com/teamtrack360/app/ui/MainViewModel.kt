package com.teamtrack360.app.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teamtrack360.app.data.AppDb
import com.teamtrack360.app.data.CircleEntity
import com.teamtrack360.app.data.MemberEntity
import com.teamtrack360.app.data.MessageEntity
import com.teamtrack360.app.data.SessionState
import com.teamtrack360.app.data.SessionStore
import com.teamtrack360.app.data.TrailPoint
import com.teamtrack360.app.data.hasLocationPermission
import com.teamtrack360.app.location.TrackingService
import com.teamtrack360.app.sync.SyncScheduler
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(private val app: Application) : AndroidViewModel(app) {

    private val store = SessionStore(app)
    private val dao = AppDb.get(app).dao()

    private val _session = MutableStateFlow(store.load())
    val session: StateFlow<SessionState> = _session

    val error = MutableStateFlow<String?>(null)

    private fun setSession(s: SessionState) {
        store.save(s)
        _session.value = s
    }

    private fun <T> forCircle(empty: T, block: (String) -> Flow<T>): StateFlow<T> =
        _session.flatMapLatest { s -> s.circleCode?.let(block) ?: flowOf(empty) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), empty)

    val members: StateFlow<List<MemberEntity>> = forCircle(emptyList()) { dao.members(it) }
    val messages: StateFlow<List<MessageEntity>> = forCircle(emptyList()) { dao.messages(it) }
    val points: StateFlow<List<TrailPoint>> = forCircle(emptyList()) { dao.allTrails(it) }
    val circle: StateFlow<CircleEntity?> = forCircle(null) { dao.circleFlow(it) }

    // ---------- auth ----------
    fun loginLocal(name: String) {
        setSession(SessionState(userId = "local-" + UUID.randomUUID().toString().take(8), name = name.ifBlank { "Me" }))
    }

    fun loginGoogle(id: String, name: String, email: String?) {
        setSession(SessionState(userId = "g-$id", name = name, email = email, google = true))
    }

    fun logout() {
        app.stopService(Intent(app, TrackingService::class.java))
        setSession(SessionState())
    }

    // ---------- circles ----------
    private fun newCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..6).map { chars.random() }.joinToString("")
    }

    fun createCircle(name: String) {
        val s = _session.value
        val uid = s.userId ?: return
        viewModelScope.launch {
            val code = newCode()
            dao.upsertCircle(CircleEntity(code, name.ifBlank { "My Team" }, uid, System.currentTimeMillis()))
            dao.upsertMember(MemberEntity(code, uid, s.name ?: "Me", true))
            error.value = null
            setSession(_session.value.copy(circleCode = code, sharing = true))
            ensureService()
        }
    }

    fun joinCircle(rawCode: String) {
        val s = _session.value
        val uid = s.userId ?: return
        val code = rawCode.trim().uppercase()
        if (code.length != 6) {
            error.value = "Code must be 6 characters"
            return
        }
        viewModelScope.launch {
            var c = dao.circle(code)
            if (c == null) {
                // Local mode cannot verify codes with a server: create a local copy of the circle.
                c = CircleEntity(code, "Circle $code", "", System.currentTimeMillis())
                dao.upsertCircle(c)
            }
            if (dao.member(code, uid) == null) {
                dao.upsertMember(MemberEntity(code, uid, s.name ?: "Me", c.adminId == uid))
            }
            error.value = null
            setSession(_session.value.copy(circleCode = code, sharing = true))
            ensureService()
        }
    }

    fun leaveCircle() {
        app.stopService(Intent(app, TrackingService::class.java))
        setSession(_session.value.copy(circleCode = null, sharing = false))
    }

    // ---------- sharing / service ----------
    fun ensureService() {
        val s = _session.value
        if (s.sharing && s.circleCode != null && hasLocationPermission(app)) {
            try {
                ContextCompat.startForegroundService(app, Intent(app, TrackingService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    fun setSharing(on: Boolean) {
        setSession(_session.value.copy(sharing = on))
        if (on) ensureService() else app.stopService(Intent(app, TrackingService::class.java))
    }

    // ---------- admin permissions ----------
    fun setPerms(m: MemberEntity, live: Boolean, trails: Boolean, own: Boolean) {
        viewModelScope.launch { dao.setPerms(m.circleCode, m.userId, live, trails, own) }
    }

    // ---------- chat ----------
    fun sendMessage(text: String) {
        val s = _session.value
        val code = s.circleCode ?: return
        val uid = s.userId ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            dao.addMessage(
                MessageEntity(
                    UUID.randomUUID().toString(), code, uid, s.name ?: "Me",
                    text.trim(), System.currentTimeMillis(), false
                )
            )
            SyncScheduler.kick(app)
        }
    }

    // ---------- demo ----------
    fun addDemoMember() {
        val s = _session.value
        val code = s.circleCode ?: return
        viewModelScope.launch {
            val id = "demo-" + UUID.randomUUID().toString().take(6)
            val name = listOf("Alex", "Sam", "Jordan", "Mika", "Riley").random() + " (demo)"
            val base = points.value.firstOrNull { it.userId == s.userId }
            var lat = (base?.lat ?: 14.5995) + Random.nextDouble(-0.004, 0.004)
            var lon = (base?.lon ?: 120.9842) + Random.nextDouble(-0.004, 0.004)
            val now = System.currentTimeMillis()
            repeat(12) { i ->
                lat += Random.nextDouble(-0.0008, 0.0008)
                lon += Random.nextDouble(-0.0008, 0.0008)
                dao.addPoint(TrailPoint(circleCode = code, userId = id, lat = lat, lon = lon, time = now - (12 - i) * 120_000L))
            }
            val gpsOn = Random.nextInt(4) != 0
            dao.upsertMember(
                MemberEntity(
                    code, id, name, false,
                    lat = lat, lon = lon,
                    battery = Random.nextInt(8, 100), charging = Random.nextBoolean(),
                    gpsOn = gpsOn, gpsOffSince = if (gpsOn) null else now - 600_000L,
                    lastSeen = now
                )
            )
        }
    }
}
